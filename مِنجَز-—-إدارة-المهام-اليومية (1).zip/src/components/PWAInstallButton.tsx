import React, { useState } from 'react';
import {
  CheckCircle2,
  Download,
  Laptop,
  Share,
  Smartphone,
  Sparkles,
  X,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'topbar' | 'banner' | 'drawer';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  variant = 'topbar',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [activeDeviceTab, setActiveDeviceTab] = useState<'android' | 'ios' | 'desktop'>(
    isIOS ? 'ios' : 'android'
  );
  const [installSuccess, setInstallSuccess] = useState(false);

  const handleInstallClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        setInstallSuccess(true);
      }
    } else {
      setShowGuideModal(true);
    }
  };

  if (isInstalled && variant === 'banner') {
    return null;
  }

  return (
    <>
      {variant === 'topbar' && (
        <button
          type="button"
          onClick={handleInstallClick}
          aria-label="تحميل وتثبيت التطبيق على الهاتف أو الحاسوب"
          title="تحميل وتثبيت التطبيق"
          className="w-7.5 h-7.5 sm:w-auto sm:h-8 sm:px-2.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-600 dark:text-amber-300 border border-amber-500/40 inline-flex items-center justify-center gap-1.5 text-xs font-bold transition-colors cursor-pointer shrink-0 whitespace-nowrap"
        >
          <Download className="w-3.5 h-3.5 shrink-0 text-amber-500 dark:text-amber-400" aria-hidden="true" />
          <span className="hidden sm:inline">تحميل التطبيق</span>
        </button>
      )}

      {variant === 'banner' && (
        <div
          role="region"
          aria-label="بطاقة تحميل وتثبيت التطبيق على الهاتف"
          className="p-3.5 rounded-2xl bg-gradient-to-l from-amber-500/15 via-[#12131A] to-[#0B0C10] border border-amber-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl royal-gold-btn flex items-center justify-center shrink-0 shadow-xs">
              <Smartphone className="w-5 h-5 text-zinc-950 shrink-0" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <h2 className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-amber-200 font-display truncate">
                  تحميل تطبيق مهام المهندس حسين علاء
                </h2>
                <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-md bg-amber-500/20 text-amber-400 border border-amber-500/30 shrink-0">
                  PWA
                </span>
              </div>
              <p className="text-[11px] text-zinc-600 dark:text-zinc-400 mt-0.5 leading-snug">
                ثبّت التطبيق على شاشة هاتفك الرئيسية ليعمل كتطبيق مستقل بكامل الشاشة وحتى بدون إنترنت.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleInstallClick}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl royal-gold-btn cursor-pointer shrink-0 whitespace-nowrap shadow-sm"
          >
            <Download className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            <span>{isInstallable ? 'تثبيت التطبيق الآن' : 'تحميل وتثبيت التطبيق'}</span>
          </button>
        </div>
      )}

      {variant === 'drawer' && (
        <button
          type="button"
          onClick={handleInstallClick}
          className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold royal-gold-btn cursor-pointer shadow-sm"
        >
          <span className="flex items-center gap-2 truncate">
            <Download className="w-4 h-4 text-zinc-950 shrink-0" aria-hidden="true" />
            <span className="truncate">تحميل وتثبيت التطبيق على الجهاز</span>
          </span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-950/20 text-zinc-950 font-mono">
            تثبيت مباشر
          </span>
        </button>
      )}

      {/* Interactive Installation Modal / Guide */}
      {showGuideModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="نافذة تحميل وتثبيت التطبيق"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-3.5 animate-in fade-in duration-200"
          onClick={() => setShowGuideModal(false)}
        >
          <div
            className="w-full max-w-md rounded-3xl bg-white dark:bg-[#0D0E13] border border-zinc-200 dark:border-amber-500/40 p-5 shadow-2xl space-y-4 text-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-3 border-b border-zinc-200 dark:border-zinc-800 pb-3.5">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-10 h-10 rounded-xl royal-gold-btn flex items-center justify-center shrink-0 shadow-sm">
                  <Download className="w-5 h-5 text-zinc-950 shrink-0" aria-hidden="true" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm sm:text-base font-bold font-display text-zinc-900 dark:text-amber-200 leading-snug">
                    تحميل تطبيق المهندس حسين علاء
                  </h3>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5">
                    تثبيت مباشر على الهاتف (Android / iPhone) أو الحاسوب
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                aria-label="إغلاق نافذة تحميل التطبيق"
                className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white cursor-pointer shrink-0"
              >
                <X className="w-4 h-4 shrink-0" aria-hidden="true" />
              </button>
            </div>

            {/* Direct Native Install Button if supported by browser */}
            {isInstallable && (
              <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/40 space-y-2.5">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-300">
                  <Sparkles className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>متصفحك يدعم التثبيت المباشر بنقرة واحدة!</span>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    const ok = await install();
                    if (ok) {
                      setInstallSuccess(true);
                      setShowGuideModal(false);
                    }
                  }}
                  className="w-full py-2.5 px-4 rounded-xl royal-gold-btn text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <Download className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>تثبيت التطبيق الآن على الجهاز</span>
                </button>
              </div>
            )}

            {installSuccess && (
              <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/40 flex items-center gap-2 text-xs text-emerald-400 font-bold">
                <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>تم إرسال طلب تثبيت التطبيق بنجاح إلى جهازك!</span>
              </div>
            )}

            {/* Platform Selector Tabs */}
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-zinc-100 dark:bg-[#14161E] border border-zinc-200 dark:border-zinc-800">
              <button
                type="button"
                onClick={() => setActiveDeviceTab('android')}
                className={`py-2 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeDeviceTab === 'android'
                    ? 'royal-gold-btn shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-amber-300'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>أندرويد</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveDeviceTab('ios')}
                className={`py-2 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeDeviceTab === 'ios'
                    ? 'royal-gold-btn shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-amber-300'
                }`}
              >
                <Share className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>آيفون iOS</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveDeviceTab('desktop')}
                className={`py-2 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  activeDeviceTab === 'desktop'
                    ? 'royal-gold-btn shadow-xs'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-amber-300'
                }`}
              >
                <Laptop className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>الحاسوب</span>
              </button>
            </div>

            {/* Step-by-step instructions per platform */}
            {activeDeviceTab === 'android' && (
              <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-[#12141C] border border-zinc-200 dark:border-amber-500/25 space-y-2.5 text-xs">
                <h4 className="font-bold text-amber-600 dark:text-amber-300 flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>خطوات التثبيت على هواتف أندرويد (Chrome):</span>
                </h4>
                <ol className="space-y-2 text-zinc-700 dark:text-zinc-300 list-decimal list-inside leading-relaxed">
                  <li>
                    افتح رابط التطبيق في متصفح <strong>Google Chrome</strong>.
                  </li>
                  <li>
                    اضغط على قائمة المتصفح العلوية <strong>(⋮ ثلاث نقاط)</strong> في الزاوية.
                  </li>
                  <li>
                    اختر <strong>«تثبيت التطبيق» (Install App)</strong> أو{' '}
                    <strong>«الإضافة إلى الشاشة الرئيسية»</strong>.
                  </li>
                  <li>
                    اضغط <strong>تثبيت</strong> لتظهر أيقونة التطبيق الذهبية مباشرة بين تطبيقات هاتفك.
                  </li>
                </ol>
              </div>
            )}

            {activeDeviceTab === 'ios' && (
              <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-[#12141C] border border-zinc-200 dark:border-amber-500/25 space-y-2.5 text-xs">
                <h4 className="font-bold text-amber-600 dark:text-amber-300 flex items-center gap-1.5">
                  <Share className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>خطوات التثبيت على آيفون وآيباد (Safari):</span>
                </h4>
                <ol className="space-y-2 text-zinc-700 dark:text-zinc-300 list-decimal list-inside leading-relaxed">
                  <li>
                    افتح التطبيق عبر متصفح <strong>Safari</strong> في جهاز الآيفون.
                  </li>
                  <li>
                    اضغط على أيقونة <strong>المشاركة (Share)</strong> في الشريط السفلي.
                  </li>
                  <li>
                    مرّر للأسفل واختر <strong>«إضافة إلى الشاشة الرئيسية» (Add to Home Screen)</strong>.
                  </li>
                  <li>
                    اضغط <strong>إضافة (Add)</strong> في أعلى الزاوية ليظهر التطبيق فوراً على شاشتك.
                  </li>
                </ol>
              </div>
            )}

            {activeDeviceTab === 'desktop' && (
              <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-[#12141C] border border-zinc-200 dark:border-amber-500/25 space-y-2.5 text-xs">
                <h4 className="font-bold text-amber-600 dark:text-amber-300 flex items-center gap-1.5">
                  <Laptop className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>خطوات التثبيت على الحاسوب (Windows / Mac):</span>
                </h4>
                <ol className="space-y-2 text-zinc-700 dark:text-zinc-300 list-decimal list-inside leading-relaxed">
                  <li>
                    انقر على أيقونة <strong>التثبيت (⊕ أو شاشة بداخلها سهم)</strong> في شريط العنوان أعلى متصفح Chrome أو Edge.
                  </li>
                  <li>
                    أو افتح التطبيق في نافذة مستقلة ثم اضغط زر <strong>«تثبيت التطبيق»</strong>.
                  </li>
                  <li>
                    سيعمل التطبيق في نافذة مستقلة على سطح المكتب مع دعم العمل دون اتصال.
                  </li>
                </ol>
              </div>
            )}

            {/* Open in new tab helper if inside preview iframe */}
            <div className="pt-2 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-2">
              <a
                href={typeof window !== 'undefined' ? window.location.href : '/'}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] font-bold text-amber-600 dark:text-amber-400 hover:underline"
              >
                فتح الرابط في متصفح الهاتف الخارجي للتثبيت ↗
              </a>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-300 dark:hover:bg-zinc-700 cursor-pointer"
              >
                تم، فهمت
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
